// Бэкенд веб-виджета бота-продажника курса.
// Чистый Node (http + fetch), без зависимостей. Node 18+.
//
// Виджет на сайте шлёт POST /chat { messages: [...] } -> { reply, leadSaved }.
// Мозг тот же, что у Telegram-бота: system-prompt.md + knowledge-base.md рядом.
// Лид: Claude выдаёт скрытый блок <<<LEAD {...}>>>, бэкенд вырезает его,
// пишет в leads.jsonl и пингует владельца в Telegram (если задан токен).
//
// Запуск: скопировать .env.example -> .env, заполнить, `node server.js`.

const http = require("http");
const fs = require("fs");
const path = require("path");

// ---- .env ----
function loadEnv() {
  const p = path.join(__dirname, ".env");
  if (!fs.existsSync(p)) { console.error(".env не найден"); process.exit(1); }
  for (const line of fs.readFileSync(p, "utf8").split("\n")) {
    const s = line.trim();
    if (!s || s.startsWith("#") || !s.includes("=")) continue;
    const i = s.indexOf("=");
    const k = s.slice(0, i).trim(), v = s.slice(i + 1).trim();
    if (!(k in process.env)) process.env[k] = v;
  }
}
loadEnv();

const API_KEY = process.env.ANTHROPIC_API_KEY;
const MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-5";
const PORT = process.env.PORT || 3000;
const OWNER = process.env.OWNER_CHAT_ID || "";
const TG_TOKEN = process.env.TELEGRAM_BOT_TOKEN || "";
if (!API_KEY) { console.error("ANTHROPIC_API_KEY не задан в .env"); process.exit(1); }

// ---- ядро: промпт + база знаний (кэшируется на стороне Claude) ----
function read(f) { return fs.readFileSync(path.join(__dirname, f), "utf8"); }
const SYSTEM_PROMPT = read("system-prompt.md");
const KNOWLEDGE_BASE = read("knowledge-base.md");
const SYSTEM_BLOCKS = [
  { type: "text", text: SYSTEM_PROMPT },
  { type: "text", text: "\n\n# БАЗА ЗНАНИЙ (источник истины по фактам о курсе)\n" + KNOWLEDGE_BASE, cache_control: { type: "ephemeral" } },
];
console.log("Ядро: промпт", SYSTEM_PROMPT.length, "+ база", KNOWLEDGE_BASE.length, "символов");

// ---- лид ----
const LEAD_RE = /<<<LEAD\s*(\{[\s\S]*?\})\s*>>>/;
const LEADS_FILE = path.join(__dirname, "leads.jsonl");

function extractLead(text) {
  const m = text.match(LEAD_RE);
  if (!m) return [text, null];
  const clean = text.replace(LEAD_RE, "").trim();
  let lead = null;
  try { lead = JSON.parse(m[1]); } catch (e) { console.error("LEAD parse fail:", e.message); }
  return [clean, lead];
}

function saveLeadFile(lead) {
  try { fs.appendFileSync(LEADS_FILE, JSON.stringify({ ts: new Date().toISOString(), ...lead }) + "\n"); return true; }
  catch (e) { console.error("leads file fail:", e.message); return false; }
}

// Создаёт СДЕЛКУ в Bitrix24 (воронка "Продажи", стадия "Новый"). Тот же паттерн, что у Mg-бота.
async function saveLeadToBitrix(lead) {
  const base = process.env.BITRIX_WEBHOOK_URL;
  if (!base) return null; // вебхук не задан - тихо пропускаем (лид уже в файле + Telegram)
  const url = base.replace(/\/?$/, "/") + "crm.deal.add.json";
  const contact = lead.phone || lead.email || lead.contact || "-";
  const summary = `Имя: ${lead.name || "-"}\nКонтакт: ${contact}\nЗапрос: ${lead.comment || lead.need || ""}\nИсточник: чат курса на сайте.`;
  const fields = {
    TITLE: `Чат курса (сайт): ${lead.name || "клиент"} - ${(lead.comment || lead.need || "заявка").slice(0, 50)}`,
    CATEGORY_ID: process.env.BITRIX_CATEGORY_ID || 0, // воронка "Продажи" (главная)
    STAGE_ID: "NEW",                                  // стадия "Новый запрос"
    SOURCE_ID: process.env.BITRIX_SOURCE_ID || "UC_889IW1", // источник WEB
    SOURCE_DESCRIPTION: "Чат-бот курса (сайт)",
    COMMENTS: summary,
    UF_CRM_1782771025: summary,                       // кастомное поле "Комментарий"
  };
  const res = await fetch(url, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fields, params: { REGISTER_SONET_EVENT: "Y" } }),
  });
  const data = await res.json();
  if (data.error) throw new Error("Bitrix: " + (data.error_description || data.error));
  return data.result; // id сделки
}

async function notifyOwner(lead) {
  if (!OWNER || !TG_TOKEN) return;
  const text = `НОВЫЙ ЛИД с сайта (курс)\nИмя: ${lead.name || "-"}\nКонтакт: ${lead.phone || lead.email || lead.contact || "-"}\nЗапрос: ${lead.comment || lead.need || "-"}`;
  try {
    await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: OWNER, text }),
    });
  } catch (e) { console.error("notifyOwner fail:", e.message); }
}

// ---- Claude ----
async function askClaude(messages) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-api-key": API_KEY, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: MODEL, max_tokens: 1024, system: SYSTEM_BLOCKS, messages }),
  });
  if (!res.ok) throw new Error("Claude " + res.status + ": " + (await res.text()).slice(0, 300));
  const data = await res.json();
  return (data.content || []).filter((c) => c.type === "text").map((c) => c.text).join("").trim();
}

// ---- HTTP ----
const CORS = {
  "Access-Control-Allow-Origin": process.env.ALLOW_ORIGIN || "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

const server = http.createServer((req, res) => {
  if (req.method === "OPTIONS") { res.writeHead(204, CORS); return res.end(); }
  if (req.method === "GET" && req.url === "/health") { res.writeHead(200, CORS); return res.end("ok"); }
  if (req.method !== "POST" || req.url !== "/chat") { res.writeHead(404, CORS); return res.end("not found"); }

  let body = "";
  req.on("data", (c) => { body += c; if (body.length > 100000) req.destroy(); });
  req.on("end", async () => {
    try {
      const parsed = JSON.parse(body || "{}");
      const messages = Array.isArray(parsed.messages) ? parsed.messages.slice(-30) : [];
      let reply = await askClaude(messages);
      reply = reply.replace(/[—–]/g, "-"); // длинное/среднее тире -> дефис (правило Стаса)
      const [clean, lead] = extractLead(reply);
      let leadSaved = false;
      if (lead) {
        saveLeadFile(lead);                       // durable: на диск всегда
        await notifyOwner(lead);                   // пинг в Telegram
        let bitrix = "не настроен";
        try { const id = await saveLeadToBitrix(lead); if (id) bitrix = "сделка " + id; }
        catch (e) { bitrix = "ОШИБКА: " + e.message; console.error("bitrix fail:", e.message); }
        leadSaved = true;
        console.log("LEAD(web):", JSON.stringify(lead), "| Bitrix:", bitrix);
      }
      res.writeHead(200, { ...CORS, "Content-Type": "application/json" });
      res.end(JSON.stringify({ reply: clean, leadSaved }));
    } catch (e) {
      console.error(e.message);
      res.writeHead(200, { ...CORS, "Content-Type": "application/json" });
      res.end(JSON.stringify({ reply: "Извините, техническая заминка. Попробуйте ещё раз через минуту.", leadSaved: false }));
    }
  });
});

server.listen(PORT, () => console.log("Бэкенд бота-продажника курса на :" + PORT));
