#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mg Lead Bot - Telegram-бот консультант Mg Accounting.
Отвечает на вопросы по бухучёту/налогам/визам человеческим языком,
доводит человека до заявки и кладёт лид в Bitrix24 (или AmoCRM).

Зависимостей НЕТ - только стандартная библиотека Python 3.
Запуск: python3 bot.py   (ключи берёт из .env рядом с файлом)

Как это работает:
  Telegram getUpdates (long-polling) -> история диалога по chat_id ->
  запрос в Claude Messages API с системным промптом (system-prompt.md) ->
  ответ пользователю. Когда Claude собрал имя + контакт + запрос,
  он выдаёт скрытый блок <<<LEAD {...}>>> - бот его вырезает,
  создаёт лид в CRM и уведомляет Стаса.
"""

import os
import re
import sys
import json
import time
import html
import traceback
import urllib.request
import urllib.parse
import urllib.error

BASE = os.path.dirname(os.path.abspath(__file__))


# ----------------------------- config / .env --------------------------------

def load_env():
    """Читает .env рядом со скриптом в os.environ (KEY=VALUE, # - коммент)."""
    path = os.path.join(BASE, ".env")
    if not os.path.exists(path):
        die(".env не найден. Скопируй .env.example в .env и впиши ключи.")
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, val = line.split("=", 1)
            os.environ.setdefault(key.strip(), val.strip())


def cfg(key, default=None, required=False):
    val = os.environ.get(key, default)
    if required and not val:
        die(f"В .env не задан обязательный параметр {key}")
    return val


def die(msg):
    print(f"[ОШИБКА] {msg}", flush=True)
    sys.exit(1)


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


# ----------------------------- HTTP helper ----------------------------------

def http_post_json(url, payload, headers=None, timeout=90):
    data = json.dumps(payload).encode("utf-8")
    hdr = {"Content-Type": "application/json"}
    if headers:
        hdr.update(headers)
    req = urllib.request.Request(url, data=data, headers=hdr, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def http_get_json(url, timeout=90):
    req = urllib.request.Request(url, method="GET")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


# ----------------------------- Claude API -----------------------------------

CLAUDE_URL = "https://api.anthropic.com/v1/messages"


def ask_claude(system_blocks, history):
    """system_blocks - список content-блоков для system (с кэшем на базе знаний).
    history - список {'role': 'user'|'assistant', 'content': '...'}."""
    payload = {
        "model": cfg("CLAUDE_MODEL", "claude-sonnet-5"),
        "max_tokens": 1024,
        "system": system_blocks,
        "messages": history,
    }
    headers = {
        "x-api-key": cfg("ANTHROPIC_API_KEY", required=True),
        "anthropic-version": "2023-06-01",
    }
    try:
        resp = http_post_json(CLAUDE_URL, payload, headers)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        log(f"Claude API HTTP {e.code}: {body[:400]}")
        return "Секунду, у меня технический сбой. Напиши, пожалуйста, ещё раз - или оставь телефон, и мы сами свяжемся."
    except Exception as e:
        log(f"Claude API error: {e}")
        return "Секунду, у меня технический сбой. Напиши, пожалуйста, ещё раз - или оставь телефон, и мы сами свяжемся."

    parts = [b.get("text", "") for b in resp.get("content", []) if b.get("type") == "text"]
    return "".join(parts).strip() or "..."


# ----------------------------- CRM (Bitrix24) -------------------------------

LEAD_RE = re.compile(r"<<<LEAD\s*(\{.*?\})\s*>>>", re.DOTALL)


def extract_lead(text):
    """Достаёт скрытый JSON лида и возвращает (чистый_текст, lead|None)."""
    m = LEAD_RE.search(text)
    if not m:
        return text, None
    clean = LEAD_RE.sub("", text).strip()
    try:
        lead = json.loads(m.group(1))
    except Exception as e:
        log(f"Не распарсил LEAD JSON: {e}")
        lead = None
    return clean, lead


def push_lead_bitrix(lead, chat_id, username):
    """Создаёт СДЕЛКУ в Bitrix24: воронка "Продажи" (0), стадия "Новый запрос" (NEW),
    источник Телеграм (UC_1SJ95D). Воронка "Лиды" отключена. Возвращает True/False."""
    webhook = cfg("BITRIX_WEBHOOK_URL")
    if not webhook:
        log("BITRIX_WEBHOOK_URL не задан - лид только в лог/личку.")
        return False
    if not webhook.endswith("/"):
        webhook += "/"

    contact = lead.get("phone") or lead.get("email") or (f"@{username}" if username else str(chat_id))
    summary = (f"Имя: {lead.get('name', '-')}\nКонтакт: {contact}\n"
               f"Запрос: {lead.get('comment', '')}\nИсточник: Telegram-бот курса.")
    fields = {
        "TITLE": f"Чат курса (Telegram): {lead.get('name', 'клиент')} - {(lead.get('comment', 'заявка'))[:50]}",
        "CATEGORY_ID": cfg("BITRIX_CATEGORY_ID", "0"),   # воронка "Продажи" (главная)
        "STAGE_ID": "NEW",                                # стадия "Новый запрос"
        "SOURCE_ID": cfg("BITRIX_SOURCE_ID", "UC_1SJ95D"),  # источник Телеграм
        "SOURCE_DESCRIPTION": f"Telegram @{username or chat_id}",
        "COMMENTS": summary,
        "UF_CRM_1782771025": summary,                     # кастомное поле "Комментарий"
    }

    try:
        resp = http_post_json(webhook + "crm.deal.add.json", {"fields": fields, "params": {"REGISTER_SONET_EVENT": "Y"}})
    except urllib.error.HTTPError as e:
        log(f"Bitrix HTTP {e.code}: {e.read().decode('utf-8','replace')[:300]}")
        return False
    except Exception as e:
        log(f"Bitrix error: {e}")
        return False

    if resp.get("result"):
        log(f"Сделка создана в Bitrix24, ID={resp['result']}")
        return True
    log(f"Bitrix ответил без result: {json.dumps(resp)[:300]}")
    return False


# ----------------------------- Telegram -------------------------------------

def tg_api(method, params=None):
    token = cfg("TELEGRAM_BOT_TOKEN", required=True)
    url = f"https://api.telegram.org/bot{token}/{method}"
    if params:
        return http_post_json(url, params)
    return http_get_json(url)


def tg_send(chat_id, text):
    # Telegram лимит 4096 символов - режем на всякий.
    for chunk in [text[i:i + 3900] for i in range(0, len(text), 3900)] or [text]:
        try:
            tg_api("sendMessage", {"chat_id": chat_id, "text": chunk, "disable_web_page_preview": True})
        except Exception as e:
            log(f"sendMessage error: {e}")


def notify_owner(text):
    """Пингует Стаса о новом лиде (если задан OWNER_CHAT_ID)."""
    owner = cfg("OWNER_CHAT_ID")
    if owner:
        try:
            tg_api("sendMessage", {"chat_id": owner, "text": text})
        except Exception as e:
            log(f"notify_owner error: {e}")


# ----------------------------- state ----------------------------------------

STATE_PATH = os.path.join(BASE, "state.json")
HISTORY = {}          # chat_id -> [ {role, content}, ... ]
OFFSET = {"value": 0}  # last processed update_id + 1
MAX_TURNS = 24         # держим последние N реплик, чтобы не раздувать контекст


def load_state():
    if os.path.exists(STATE_PATH):
        try:
            with open(STATE_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            HISTORY.update(data.get("history", {}))
            OFFSET["value"] = data.get("offset", 0)
            log(f"Состояние загружено: {len(HISTORY)} диалогов, offset={OFFSET['value']}")
        except Exception as e:
            log(f"Не загрузил state: {e}")


def save_state():
    try:
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump({"history": HISTORY, "offset": OFFSET["value"]}, f, ensure_ascii=False)
    except Exception as e:
        log(f"Не сохранил state: {e}")


# ----------------------------- system prompt --------------------------------

def load_system_prompt():
    path = os.path.join(BASE, "system-prompt.md")
    if not os.path.exists(path):
        die("system-prompt.md не найден рядом с bot.py")
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def load_knowledge_base():
    """База знаний Mg (ОАЭ+Кипр). Собирается build-kb.py. Нет файла - бот работает без неё."""
    path = os.path.join(BASE, "knowledge-base.md")
    if not os.path.exists(path):
        log("knowledge-base.md не найден - запусти build-kb.py. Работаю без базы знаний.")
        return ""
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def build_system_blocks(system_prompt, knowledge_base):
    """Системный контекст: промпт + база знаний. База помечена cache_control -
    Claude кэширует её, и мы не платим за ~30k токенов на каждом сообщении."""
    blocks = [{"type": "text", "text": system_prompt}]
    if knowledge_base:
        blocks.append({
            "type": "text",
            "text": "\n\n# БАЗА ЗНАНИЙ Mg (источник истины по фактам/цифрам)\n" + knowledge_base,
            "cache_control": {"type": "ephemeral"},
        })
    return blocks


# ----------------------------- main loop ------------------------------------

def handle_message(msg, system_blocks):
    chat = msg.get("chat", {})
    chat_id = str(chat.get("id"))
    username = chat.get("username", "")
    text = msg.get("text", "")
    if not text:
        return

    if text.strip() in ("/start", "/старт"):
        greeting = cfg("GREETING",
                       "Привет! Я консультант Mg Accounting. Расскажи в двух словах свою ситуацию: "
                       "в какой стране бизнес и что нужно (регистрация компании, бухгалтерия, налоги, виза) - "
                       "и я подскажу, как решить.")
        tg_send(chat_id, greeting)
        HISTORY[chat_id] = []
        save_state()
        return

    hist = HISTORY.setdefault(chat_id, [])
    hist.append({"role": "user", "content": text})
    hist[:] = hist[-MAX_TURNS:]

    reply = ask_claude(system_blocks, hist)
    clean, lead = extract_lead(reply)

    hist.append({"role": "assistant", "content": reply})
    hist[:] = hist[-MAX_TURNS:]
    save_state()

    if clean:
        tg_send(chat_id, clean)

    if lead:
        ok = push_lead_bitrix(lead, chat_id, username)
        summary = (f"НОВЫЙ ЛИД из Telegram\n"
                   f"Имя: {lead.get('name', '-')}\n"
                   f"Контакт: {lead.get('phone', '') or lead.get('email', '') or ('@' + username if username else chat_id)}\n"
                   f"Запрос: {lead.get('comment', '-')}\n"
                   f"CRM: {'создан' if ok else 'НЕ создан (см. лог)'}")
        notify_owner(summary)


def main():
    load_env()
    load_state()
    system_prompt = load_system_prompt()
    knowledge_base = load_knowledge_base()
    system_blocks = build_system_blocks(system_prompt, knowledge_base)
    log(f"Системный контекст: промпт {len(system_prompt)} + база знаний {len(knowledge_base)} символов")

    try:
        me = tg_api("getMe")
        bot_name = me.get("result", {}).get("username", "?")
        log(f"Бот @{bot_name} на связи. Жду сообщения... (Ctrl+C - стоп)")
    except Exception as e:
        die(f"Не подключился к Telegram (проверь TELEGRAM_BOT_TOKEN): {e}")

    while True:
        try:
            resp = tg_api("getUpdates", {"offset": OFFSET["value"], "timeout": 50})
            for upd in resp.get("result", []):
                OFFSET["value"] = upd["update_id"] + 1
                msg = upd.get("message") or upd.get("edited_message")
                if msg:
                    try:
                        handle_message(msg, system_blocks)
                    except Exception:
                        log("Ошибка в handle_message:\n" + traceback.format_exc())
            save_state()
        except urllib.error.HTTPError as e:
            log(f"Telegram HTTP {e.code}, жду 5с")
            time.sleep(5)
        except KeyboardInterrupt:
            log("Останов по Ctrl+C. Пока!")
            save_state()
            break
        except Exception as e:
            log(f"Цикл упал: {e}, жду 5с")
            time.sleep(5)


if __name__ == "__main__":
    main()
