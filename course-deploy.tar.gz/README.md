# Деплой-пакет ботов курса (под ключ)

Разворачивает Telegram-бота-продажника + веб-виджет курса на сервере рядом с ХУЛИЛОГОС.

## Как развернуть на сервере 147.45.172.251 (где боты)
1. Скопировать эту папку на сервер (scp/rsync/git), напр. в /root/course-deploy
2. `cd course-deploy && sudo bash install.sh`
3. Ввести ANTHROPIC_API_KEY и TELEGRAM_BOT_TOKEN когда спросит (или заранее export)
4. Для HTTPS: A-запись chat.maizongroup.com -> IP сервера, скрипт сам выпустит сертификат

Bitrix-вебхук, источники, chat_id владельца, воронка - уже прошиты в install.sh.
После деплоя: виджет на audit.maizongroup.com/course/ уже указывает на https://chat.maizongroup.com/chat.
