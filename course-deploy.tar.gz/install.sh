#!/usr/bin/env bash
# Разворачивает ОБОИХ ботов курса на сервере (рядом с ХУЛИЛОГОС/ИИ-бухом):
#   - Telegram-бот-продажник курса (@aisales888_bot) -> systemd course-tg-bot
#   - Веб-виджет backend (чат на сайте /course/)     -> systemd course-web + nginx HTTPS
#
# ЗАПУСК на сервере (из папки, куда скопирован этот пакет: course-bot/ и course-widget/ рядом):
#   sudo bash install.sh
# Ключи бот спросит интерактивно (или заранее export ANTHROPIC_API_KEY=... TELEGRAM_BOT_TOKEN=...).
set -euo pipefail

DOMAIN="${DOMAIN:-chat.maizongroup.com}"
BASE="$(cd "$(dirname "$0")" && pwd)"
WEBHOOK="${BITRIX_WEBHOOK_URL:-}"   # передаётся через env при запуске, НЕ хардкодится

echo "== 1/6 Node =="
if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
node -v

echo "== 2/6 код в /opt =="
mkdir -p /opt/course-bot /opt/course-widget
cp -r "$BASE/course-bot/." /opt/course-bot/
cp -r "$BASE/course-widget/." /opt/course-widget/

echo "== 3/6 ключи =="
: "${ANTHROPIC_API_KEY:=}"; : "${TELEGRAM_BOT_TOKEN:=}"
if [ -z "$ANTHROPIC_API_KEY" ]; then read -rp "ANTHROPIC_API_KEY: " ANTHROPIC_API_KEY; fi
if [ -z "$TELEGRAM_BOT_TOKEN" ]; then read -rp "TELEGRAM_BOT_TOKEN (@aisales888_bot): " TELEGRAM_BOT_TOKEN; fi

cat > /opt/course-bot/.env <<EOF
ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY
TELEGRAM_BOT_TOKEN=$TELEGRAM_BOT_TOKEN
OWNER_CHAT_ID=712775843
CLAUDE_MODEL=claude-opus-4-8
BITRIX_WEBHOOK_URL=$WEBHOOK
BITRIX_CATEGORY_ID=0
BITRIX_SOURCE_ID=UC_1SJ95D
GREETING=Привет! Я консультант программы «Цифровая команда компании» - обучение работе с ИИ через Claude Code (ведут Стас и Михаил). Напишите в двух словах: это для вашей команды или для себя, чем занимается бизнес и что хотите закрыть с помощью ИИ - подскажу, какой формат подойдёт.
EOF
cat > /opt/course-widget/.env <<EOF
ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY
CLAUDE_MODEL=claude-opus-4-8
PORT=3020
ALLOW_ORIGIN=https://audit.maizongroup.com
TELEGRAM_BOT_TOKEN=$TELEGRAM_BOT_TOKEN
OWNER_CHAT_ID=712775843
BITRIX_WEBHOOK_URL=$WEBHOOK
BITRIX_CATEGORY_ID=0
BITRIX_SOURCE_ID=UC_889IW1
EOF
chmod 600 /opt/course-bot/.env /opt/course-widget/.env

echo "== 4/6 systemd сервисы =="
cat > /etc/systemd/system/course-tg-bot.service <<'EOF'
[Unit]
Description=Course sales Telegram bot
After=network-online.target
Wants=network-online.target
[Service]
WorkingDirectory=/opt/course-bot
ExecStart=/usr/bin/python3 -u bot.py
Environment=PYTHONUTF8=1
Environment=LANG=C.UTF-8
Environment=LC_ALL=C.UTF-8
Restart=always
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF
cat > /etc/systemd/system/course-web.service <<'EOF'
[Unit]
Description=Course web widget backend
After=network-online.target
Wants=network-online.target
[Service]
WorkingDirectory=/opt/course-widget
ExecStart=/usr/bin/node server.js
Environment=LANG=C.UTF-8
Environment=LC_ALL=C.UTF-8
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now course-tg-bot course-web
sleep 2
systemctl --no-pager status course-tg-bot | head -4
systemctl --no-pager status course-web | head -4

echo "== 5/6 nginx + HTTPS для $DOMAIN =="
if command -v nginx >/dev/null 2>&1; then
  cat > /etc/nginx/sites-available/$DOMAIN.conf <<EOF
server {
    server_name $DOMAIN;
    location / { proxy_pass http://127.0.0.1:3020; proxy_set_header Host \$host; }
}
EOF
  ln -sf /etc/nginx/sites-available/$DOMAIN.conf /etc/nginx/sites-enabled/
  nginx -t && systemctl reload nginx
  if command -v certbot >/dev/null 2>&1; then
    certbot --nginx -d $DOMAIN --non-interactive --agree-tos -m info@maizongroup.com || echo "certbot: настрой A-запись $DOMAIN -> IP и повтори: certbot --nginx -d $DOMAIN"
  else
    echo "certbot не установлен: apt-get install -y certbot python3-certbot-nginx, потом certbot --nginx -d $DOMAIN"
  fi
else
  echo "nginx не установлен - backend на :3020, поставь nginx+certbot для HTTPS $DOMAIN"
fi

echo "== 6/6 ГОТОВО =="
echo "Telegram-бот: journalctl -u course-tg-bot -f"
echo "Веб-бэкенд:   curl https://$DOMAIN/health   (после HTTPS)"
echo "Дальше: в site/course/index.html виджет уже указывает на https://$DOMAIN/chat"
